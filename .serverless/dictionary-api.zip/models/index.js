const Dictionary = require('./Dictionary');

module.exports = { Dictionary };